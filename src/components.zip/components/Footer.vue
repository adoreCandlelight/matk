<template>
    <div>
        <div class="footArea">
             <p class="footer">MATK &copy; 2019 The Ren Lab. All Rights Reserved</p>
        </div>
        
    </div>
</template>

<script>
export default {
    
}
</script>

<style lang="scss" scoped>
.footArea {
    background-color:lightgoldenrodyellow;
}
.footer {
    text-align: center;
    color: #777777;
    font-size: 18px;
    padding: 6px 0;
}
</style>
